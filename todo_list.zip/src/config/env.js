export const SERVER_URI = process.env.REACT_APP_SERVER_URI;
